# cto.new — Page Snapshot

This repository contains an organized export of a saved `.mht` (MHTML) page
archive from **cto.new**, split into separate files so it can be tracked in
a normal Git repository instead of one large single-file archive.

## Source

- Original file: `cto - Build anything with AI. Free forever..mht`
- Captured page: `https://cto.new/business/55c29eb5-4a41-4d4a-abf9-5dfeb9368f68/files`
  (a cto.new dashboard/business view, not the public marketing homepage)

## Structure

```
repo/
├── index.html              # The page's HTML, with local asset paths rewritten where possible
├── assets/
│   ├── css/                # Stylesheets extracted from the archive
│   └── images/              # Images/icons extracted from the archive (deduplicated by content hash)
└── README.md
```

Each asset file name includes a short content hash (e.g. `pattern-f18d894d75.svg`)
so identical assets referenced multiple times in the original archive are stored
only once.

## Known limitations

This was a **snapshot of a client-rendered web app (Next.js)**, not a static
site, so a few things won't work if you just open `index.html` locally:

- The page relies heavily on client-side JavaScript (bundled `_next/static/...`
  chunks) that was **not** embedded in the original `.mht` file, so
  interactivity/data won't load.
- Some asset references are analytics/tracking pixel URLs (Twitter Ads, Stripe
  iframes) which were intentionally **excluded** from this export.
- Only CSS and image assets that appeared as direct links in the HTML were
  rewritten to local paths; any assets referenced dynamically via JavaScript
  still point to their original `cto.new` URLs.

In short: this repo is useful for archiving/inspecting the page's markup,
styles, and images, but it will not fully render as a working app offline.
